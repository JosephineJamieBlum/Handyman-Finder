var mysql = require("mysql");
var http = require("http");
var fs = require("fs");
var express = require("express");
var app = express();

//start the express server first
app.get("/", function(req, res)
{
    //then inside connect to the local database
    //configure the connection for the local database
    var con = mysql.createConnection(
    {
        host: "localhost",
        user: "root",
        password: "password",
        //for some reason ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';
        //changed it to password when 
        database: "world"
    });

    //connect to it with the command
    con.connect(function(err) 
    {
        if (err) throw err; //throws an error for the connection itself
    
        //in each database function common practice is to throw an exception each time you call a connected function
        con.query("SELECT * FROM ClientInfo", function (err, result, fields) 
        {
          if (err) throw err; //throws an error for the query call
          console.log(result); //the results object here is used to display the whole collection
          //but I can use result[x] to select individual
          console.log(result[0]);
          //dText = result[0];
          //clientP.textContent = result[0];

          //except this time send the data using the resonse node object
          res.send(result)
        });
    
    });
})

//always put the listener at the bottom
var server = app.listen(3000, function()
{
    console.log("now listening for any requests");
})

