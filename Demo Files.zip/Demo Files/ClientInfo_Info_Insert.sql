INSERT INTO ClientInfo VALUES
( 1001, 'Tazz', 'Akber', 22, 'Male'),
( 1002, 'John', 'Doe', 30, 'Male'),
( 1003, 'Mary', 'Jane', 24, 'Female') 