var http = require("http");
var fs = require("fs");

var server = http.createServer(function(req, res)
{
    console.log("request was made to server: " + req.url);
    res.writeHead(200, {"Content-Type": "text/html"});
    fs.createReadStream("SerHTMLPage_index.html").pipe(res);
    //for some reason __dirname causes the file to become a download for the visitor
});

server.listen(3000, "127.0.0.1");
console.log("Now listening to port number 3000");