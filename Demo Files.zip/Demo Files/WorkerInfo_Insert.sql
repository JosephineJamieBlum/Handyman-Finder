INSERT INTO WorkerInfo VALUES
( 2001, 'Hubert', 'Doinks', 'Plumber', 35, 'Male'),
( 2002, 'Billy', 'Boy', 'Electrician', 42, 'Male'),
( 2003, 'Jessica', 'Parker', 'Painter', 29, 'Female')