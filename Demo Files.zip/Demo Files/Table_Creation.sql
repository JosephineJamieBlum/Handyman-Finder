CREATE TABLE ClientInfo
( ClientID int,
FirstName varchar(15),
LastName varchar(15),
Age int,
Gender varchar(10)
)

CREATE TABLE WorkerInfo
( WorkerID int,
FirstName varchar(15),
LastName varchar(15),
Profession varchar(30),
Age int,
Gender varchar(10)
)